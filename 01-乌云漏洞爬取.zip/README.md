# WebSpider

需要安装 requests 库，fake_useragent库

用户可以自定义在乌云网站爬取的对象以及爬取所需要的线程数量。爬取乌云漏洞网站大量的漏洞信息
