# 社工字典生成器

原理，根据域名中的关键字生成指定的社工字典

需要安装模块

```
pip install exrex
```

config.py 配置文件处



调用方式

```
python start.py -u '网址'
```

