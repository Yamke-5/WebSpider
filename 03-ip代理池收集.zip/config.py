'''
这个是配置文件里面存放的是重要的配置信息
'''

# 网站的地址
url = r'http://www.66ip.cn/areaindex_1/1.html'
# 网站的请求头
head = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36'
}

# url文件存放名
url_name_file = 'url.txt'

# ip文件存放名称
ip_name_file = 'ip.txt'
