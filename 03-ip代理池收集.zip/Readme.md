# IP代理池收集

## 前置

```
需要安装以下库
pip install bs4
pip install request

```



## 使用方法

```
Python start.py -t 线程数量
```

