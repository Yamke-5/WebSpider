# 目录扫描

可以扫到对应网站的url

## 前置条件

安装request库

```
pip install requests
```



## 命令操作

```
python -dic 字典位置 -u 网站地址 -t 线程数量
```

注意其中的 字典位置和 线程数量如果不传入值则有默认值。