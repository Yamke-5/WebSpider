'''
这个是配置文件
'''
# 目录扫描的网址
url = r'http://www.sql.nes'

# 字典位置
dict_name = r'./dict/php(1).txt'

# 存放文件的位置以及名字
ip_address = r'./list_ip.txt'

# 字典读取的类型
dict_type = 'gbk'

# 请求头设置
head = {
    'User_Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36'
}
